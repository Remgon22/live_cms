</div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- include summernote css/js -->
  <!--  <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script> -->

<link rel="stylesheet" href="css/summernote.css">

<script src="js/summernote.min.js"></script>
    <script src="js/scripts.js"></script>
    



</body>

</html>
